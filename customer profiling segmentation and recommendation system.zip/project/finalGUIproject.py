import pickle
import os
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
from surprise import Dataset, Reader, SVDpp
import tkinter as tk
from tkinter import messagebox, ttk
from tkinter import filedialog
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import seaborn as sns

# Check if file exists and load trained models
def load_pickle_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "rb") as f:
            return pickle.load(f)
    else:
        raise FileNotFoundError(f"File not found: {file_path}")

try:
    # Load Trained Models
    loaded_models = load_pickle_file("trained_models.pkl")
    kmeans = loaded_models['kmeans']
    rf_model = loaded_models['rf_model']
    svdpp_model = loaded_models['svdpp_model']
    imputer = loaded_models['imputer']
    trainset_full = loaded_models['trainset']

    # Load KMeans model for customer-item matrix
    kmeans_model = load_pickle_file("kmeans_model.pkl")

    # Load customer-item matrix
    customer_item_matrix = load_pickle_file("customer_item_matrix.pkl")
    
except (FileNotFoundError, pickle.UnpicklingError) as e:
    messagebox.showerror("Error", f"An error occurred while loading models: {e}")

# Load Data
data_path_csv = "data.csv"
data_path_xlsx = "data.xlsx"

# Global variables
data = None
rfm_data = None
customer_ids_with_purchases = None
filtered_df = None
sparsity = None
customer_item_matrix_scaled = None

# Function to load data and make predictions
def load_data_and_predict():
    global data, rfm_data, customer_ids_with_purchases, filtered_df, sparsity, customer_item_matrix_scaled

    try:
        data = pd.read_csv(data_path_csv)

        # Check for required columns
        required_columns = ['Customer ID', 'InvoiceDate', 'Invoice', 'Price']
        for col in required_columns:
            if col not in data.columns:
                raise KeyError(f"'{col}' column not found in the dataset.")

        # Preprocessing & Feature Engineering
        data['InvoiceDate'] = pd.to_datetime(data['InvoiceDate'])
        last_date = data['InvoiceDate'].max()

        rfm_data = data.groupby('Customer ID').agg({
            'InvoiceDate': lambda x: (last_date - x.max()).days,
            'Invoice': 'count',
            'Price': 'sum'
        })
        rfm_data.columns = ['Recency', 'Frequency', 'MonetaryValue']

        # Apply segmentation to new data
        rfm_data['Cluster'] = kmeans.predict(rfm_data)

        # Predict purchase probability (with imputation)
        X_new = rfm_data[['Recency', 'Frequency', 'MonetaryValue', 'Cluster']]
        X_new_imputed = imputer.transform(X_new)  # Use the loaded imputer
        purchase_probabilities = rf_model.predict_proba(X_new_imputed)[:, 1]
        rfm_data['PurchaseProbability'] = purchase_probabilities

        # Load data.xlsx for customer-item matrix
        df_xlsx = pd.read_excel(data_path_xlsx)
        df_xlsx['Customer ID'] = df_xlsx['Customer ID'].fillna(0).astype(int)
        df_xlsx = df_xlsx[['Customer ID', 'StockCode', 'Quantity']]

        # Create customer-item matrix
        customer_item_matrix = df_xlsx.pivot_table(
            index='Customer ID',
            columns='StockCode',
            values='Quantity',
            fill_value=0
        )

        customer_ids_with_purchases = customer_item_matrix.index
        filtered_df = df_xlsx[df_xlsx['Customer ID'].isin(customer_ids_with_purchases)]

        # Assign clusters to filtered_df
        filtered_df = pd.merge(filtered_df, rfm_data[['Cluster']], left_on='Customer ID', right_index=True, how='left')

        # Check and print sparsity
        sparsity = 1.0 - (customer_item_matrix > 0).sum().sum() / customer_item_matrix.size
        print(f"Sparsity of Customer-Item Matrix: {sparsity:.2%}")

        # Standardize data for clustering
        scaler = StandardScaler()
        customer_item_matrix_scaled = scaler.fit_transform(customer_item_matrix)

        # Update GUI
        result_label.config(text=f"Data loaded and predictions made. Click 'Show Results' to view.")
        show_results_button.config(state=tk.NORMAL)
        plot_button.config(state=tk.NORMAL)  # Enable plot button
        show_plots_button.config(state=tk.NORMAL)
        get_rec_button.config(state=tk.NORMAL)

    except KeyError as e:
        messagebox.showerror("Error", str(e))
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

# Function to display results in a new window
def show_results(rfm_data=None):
    if rfm_data is None:
        messagebox.showerror("Error", "Please load data first")
        return

    # Create a new window with larger size
    results_window = tk.Toplevel(window)
    results_window.title("Customer Segmentation Results")
    results_window.geometry("800x600")

    # Create a frame inside the window for the treeview
    frame = ttk.Frame(results_window)
    frame.pack(fill=tk.BOTH, expand=1)

    # Create a treeview with scroll bar
    tree = ttk.Treeview(frame)
    tree["columns"] = list(rfm_data.columns)
    for col in rfm_data.columns:
        tree.heading(col, text=col)
        tree.column(col, width=120)

    # Add data to the treeview
    for index, row in rfm_data.iterrows():
        tree.insert("", "end", text=index, values=list(row.round(2)))

    # Add scroll bar
    vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    vsb.pack(side="right", fill="y")
    tree.configure(yscrollcommand=vsb.set)

    # Pack the treeview
    tree.pack(side="left", fill="both", expand=True)

# Function to display RFM scatter plot
def show_rfm_plot():
    if rfm_data is None:
        messagebox.showerror("Error", "Please load data first")
        return

    # Create a figure with multiple subplots
    fig, axs = plt.subplots(2, 2, figsize=(14, 10))

    # 1. Scatter Plot of Recency vs. Frequency with Clusters
    scatter = axs[0, 0].scatter(rfm_data['Recency'], rfm_data['Frequency'], c=rfm_data['Cluster'].astype(int), cmap='viridis', s=50)  # Convert 'Cluster' to int
    axs[0, 0].set_title('Recency vs Frequency')
    axs[0, 0].set_xlabel('Recency')
    axs[0, 0].set_ylabel('Frequency')
    legend1 = axs[0, 0].legend(*scatter.legend_elements(), loc="upper right", title="Clusters")
    axs[0, 0].add_artist(legend1)

    # 2. Histogram of Recency
    axs[0, 1].hist(rfm_data['Recency'], bins=20, color='skyblue', edgecolor='black')
    axs[0, 1].set_title('Histogram of Recency')
    axs[0, 1].set_xlabel('Recency')
    axs[0, 1].set_ylabel('Frequency')

    # 3. Histogram of Frequency
    axs[1, 0].hist(rfm_data['Frequency'], bins=20, color='lightgreen', edgecolor='black')
    axs[1, 0].set_title('Histogram of Frequency')
    axs[1, 0].set_xlabel('Frequency')
    axs[1, 0].set_ylabel('Count')

    # 4. Box Plot of Monetary Value by Cluster
    rfm_data['Cluster'] = rfm_data['Cluster'].astype(int)  # Ensure 'Cluster' is treated as int
    sns.boxplot(x='Cluster', y='MonetaryValue', data=rfm_data, ax=axs[1, 1], palette='Set3')
    axs[1, 1].set_title('Box Plot of Monetary Value by Cluster')
    axs[1, 1].set_xlabel('Cluster')
    axs[1, 1].set_ylabel('Monetary Value')

    fig.tight_layout()

    # Embed plot in the Tkinter window
    plot_window = tk.Toplevel(window)
    plot_window.title("RFM Data Visualizations")
    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack()
# Function to display Elbow Method plot
def show_elbow_plot():
    global inertia, silhouette_scores, k_values

    if customer_item_matrix_scaled is None:
        messagebox.showerror("Error", "Please load data first")
        return

    # Determine optimal k
    inertia = []
    silhouette_scores = []
    k_values = range(2, 11)
    for k in k_values:
        if sparsity > 0.5:
            kmeans_temp = MiniBatchKMeans(n_clusters=k, random_state=42, batch_size=1000)
        else:
            kmeans_temp = KMeans(n_clusters=k, random_state=42)
        kmeans_temp.fit(customer_item_matrix_scaled)
        inertia.append(kmeans_temp.inertia_)
        silhouette_scores.append(silhouette_score(customer_item_matrix_scaled, kmeans_temp.labels_))

    # Elbow Method Plot
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(k_values, inertia, marker='x')
    ax.set_title('Elbow Method for Optimal k')
    ax.set_xlabel('Number of Clusters (k)')
    ax.set_ylabel('Inertia')
    ax.set_xticks(k_values)

    # Embed plot in the Tkinter window
    plot_window = tk.Toplevel(window)
    plot_window.title("Elbow Method Plot")
    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack()

# Function to get recommendations
def get_recommendations(customer_id, num_recommendations=5):
    if 'Cluster' not in filtered_df.columns:
        messagebox.showerror("Error", "Cluster information is missing in the filtered_df dataframe.")
        return []

    cluster = filtered_df[filtered_df['Customer ID'] == customer_id]['Cluster'].iloc[0]
    customer_purchases = filtered_df[filtered_df['Customer ID'] == customer_id]['StockCode']

    # Get items frequently bought by similar customers
    cluster_purchases = filtered_df[filtered_df['Cluster'] == cluster]['StockCode']
    item_popularity = cluster_purchases.value_counts()

    # Filter out already purchased items and recommend the most popular ones
    recommendations = item_popularity[~item_popularity.index.isin(customer_purchases)].head(num_recommendations)

    return recommendations.index.tolist()

# Function to get recommendations and display them in the GUI
def get_recommendations_gui(customer_id):
    try:
        recs = get_recommendations(customer_id)
        if recs:
            recommendations_text.set(f"Recommended items for Customer {customer_id}: {', '.join(map(str, recs))}")

            # Create a new window to display recommended products
            rec_window = tk.Toplevel(window)
            rec_window.title(f"Recommendations for Customer {customer_id}")
            rec_window.geometry("600x400")

            # Fetch product descriptions
            product_data = data[['StockCode', 'Description']].drop_duplicates().set_index('StockCode')
            recommended_products = product_data.loc[recs]

            # Create a frame inside the window for the treeview
            frame = ttk.Frame(rec_window)
            frame.pack(fill=tk.BOTH, expand=1)

            # Create a treeview with scroll bar
            tree = ttk.Treeview(frame)
            tree["columns"] = ["StockCode", "Description"]
            for col in ["StockCode", "Description"]:
                tree.heading(col, text=col)
                tree.column(col, width=200)

            # Add data to the treeview
            for index, row in recommended_products.iterrows():
                tree.insert("", "end", text=index, values=[index, row['Description']])

            # Add scroll bar
            vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
            vsb.pack(side="right", fill="y")
            tree.configure(yscrollcommand=vsb.set)

            # Pack the treeview
            tree.pack(side="left", fill="both", expand=True)

            # Add a text box for a better view of recommendations
            text_box = tk.Text(rec_window, height=10, width=50)
            text_box.pack(pady=10)
            text_box.insert(tk.END, "Recommended Products:\n\n")
            for stock_code, description in recommended_products.iterrows():
                text_box.insert(tk.END, f"{stock_code}: {description['Description']}\n")
            text_box.config(state=tk.DISABLED)  # Make the text box read-only
        else:
            recommendations_text.set(f"No new recommendations available for Customer {customer_id}.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred while getting recommendations: {e}")
# GUI setup (unchanged)
window = tk.Tk()
window.title("Customer Segmentation & Prediction")
window.geometry("800x600")

load_button = tk.Button(window, text="Load Data and Predict", command=load_data_and_predict)
load_button.pack(pady=20)

result_label = tk.Label(window, text="")
result_label.pack()

show_results_button = tk.Button(window, text="Show Results", command=lambda: show_results(rfm_data), state=tk.DISABLED)
show_results_button.pack(pady=10)

plot_button = tk.Button(window, text="Show RFM Plot", command=show_rfm_plot, state=tk.DISABLED)
plot_button.pack(pady=10)

show_plots_button = tk.Button(window, text="Show Elbow Plot", command=show_elbow_plot, state=tk.DISABLED)
show_plots_button.pack(pady=10)

# Recommendation Input Section
rec_frame = ttk.Frame(window)
rec_frame.pack(pady=10)

ttk.Label(rec_frame, text="Customer ID:").pack(side=tk.LEFT)
customer_id_entry = ttk.Entry(rec_frame)
customer_id_entry.pack(side=tk.LEFT, padx=5)

get_rec_button = ttk.Button(rec_frame, text="Get Recommendations", command=lambda: get_recommendations_gui(int(customer_id_entry.get())), state=tk.DISABLED)
get_rec_button.pack(side=tk.LEFT)

# Recommendation Output
recommendations_text = tk.StringVar(value="Recommendations will appear here")
recommendations_label = ttk.Label(rec_frame, textvariable=recommendations_text, wraplength=300)
recommendations_label.pack(pady=10)

window.mainloop()