import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from surprise import Dataset, Reader, SVDpp
from surprise.model_selection import cross_validate
import pickle

# Load Data (Replace with your actual file path)
data = pd.read_csv("data.csv")
data.dropna(inplace=True)
# Check for required columns
required_columns = ['Customer ID', 'InvoiceDate', 'Invoice', 'Price']
for col in required_columns:
    if col not in data.columns:
        raise KeyError(f"'{col}' column not found in the dataset.")

# Preprocessing & Feature Engineering
data['InvoiceDate'] = pd.to_datetime(data['InvoiceDate'])
last_date = data['InvoiceDate'].max()

rfm_data = data.groupby('Customer ID').agg({
    'InvoiceDate': lambda x: (last_date - x.max()).days,
    'Invoice': lambda x: len(x),
    'Price': lambda x: x.sum()
})
rfm_data.columns = ['Recency', 'Frequency', 'MonetaryValue']

# Segmentation
kmeans = KMeans(n_clusters=4, random_state=0, n_init=10)
rfm_data['Cluster'] = kmeans.fit_predict(rfm_data)

# Purchase Prediction Preparation (with Imputation)
data = data.merge(rfm_data, on='Customer ID', how='left')
X = data[['Recency', 'Frequency', 'MonetaryValue', 'Cluster']]
y = np.where(data['Price'] > 0, 1, 0)

# Handle missing values
imputer = SimpleImputer(strategy='median')
X_imputed = imputer.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_imputed, y, test_size=0.2, random_state=0)

# Purchase Prediction Model
rf_model = RandomForestClassifier(random_state=0)
rf_model.fit(X_train, y_train)

# Recommendation (Collaborative Filtering with SVD++)
reader = Reader(rating_scale=(1, 5))
ratings_data = Dataset.load_from_df(data[['Customer ID', 'Invoice', 'Price']], reader)
svdpp_model = SVDpp()
cross_validate(svdpp_model, ratings_data, measures=['RMSE', 'MAE'])
trainset = ratings_data.build_full_trainset()
svdpp_model.fit(trainset)

# Save the models
with open("trained_models.pkl", "wb") as f:
    pickle.dump({'kmeans': kmeans, 'rf_model': rf_model, 'svdpp_model': svdpp_model, 'imputer': imputer, 'trainset': trainset}, f)
