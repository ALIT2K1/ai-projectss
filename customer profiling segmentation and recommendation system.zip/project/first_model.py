import pandas as pd
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import pickle
import altair as alt
import numpy as np


# Load the data
df = pd.read_excel('data.xlsx')
# Replace NaN values with 0
df['Customer ID'].fillna(0, inplace=True)

df['Customer ID'] = df['Customer ID'].astype(int)


# Filter relevant columns
df = df[['Customer ID', 'StockCode', 'Quantity']]

# Create customer-item matrix
customer_item_matrix = df.pivot_table(index='Customer ID', columns='StockCode', values='Quantity', fill_value=0)

# Get list of customer IDs from the matrix
customer_ids_with_purchases = customer_item_matrix.index

# Filter the original DataFrame to only include customers with purchases
filtered_df = df[df['Customer ID'].isin(customer_ids_with_purchases)]

# Check Sparsity
sparsity = 1.0 - ( customer_item_matrix > 0 ).sum().sum() / customer_item_matrix.size
print(f"Sparsity of Customer-Item Matrix: {sparsity:.2%}")

# Standardize the data
scaler = StandardScaler()
customer_item_matrix_scaled = scaler.fit_transform(customer_item_matrix)

# Find the optimal number of clusters using the Elbow method and Silhouette Analysis
inertia = []
silhouette_scores = []
k_values = range(2, 11)  # Adjust the range as needed

for k in k_values:
    if sparsity > 0.5:
        kmeans = MiniBatchKMeans(n_clusters=k, random_state=42,
                                batch_size=1000)  # Use MiniBatch for sparse matrices
    else:
        kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(customer_item_matrix_scaled)
    inertia.append(kmeans.inertia_)
    silhouette_scores.append(silhouette_score(customer_item_matrix_scaled, kmeans.labels_))

# Plot the Elbow method results
plt.figure(figsize=(10, 5))
plt.plot(k_values, inertia, marker='x')
plt.title('Elbow Method for Optimal k')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Inertia')
plt.xticks(k_values)
plt.show()

# Find the optimal k based on the Silhouette analysis
optimal_k = silhouette_scores.index(max(silhouette_scores)) + 2
print(f"Optimal number of clusters (k): {optimal_k}")

# Apply K-means clustering with the optimal k
if sparsity > 0.5:
    kmeans = MiniBatchKMeans(n_clusters=optimal_k, random_state=42, batch_size=1000)
else:
    kmeans = KMeans(n_clusters=optimal_k, random_state=42)

customer_clusters = kmeans.fit_predict(customer_item_matrix_scaled)

# Create a new DataFrame with the cluster labels and customer IDs
cluster_labels_df = pd.DataFrame({'Customer ID': customer_ids_with_purchases, 'Cluster': customer_clusters})

# Merge cluster labels back into the filtered DataFrame
filtered_df = filtered_df.merge(cluster_labels_df, on='Customer ID', how='left')

# --- Cluster Analysis ---
cluster_item_counts = filtered_df.groupby(['Cluster', 'StockCode'])['Quantity'].sum().reset_index()
cluster_item_counts = cluster_item_counts.sort_values(by=['Cluster', 'Quantity'], ascending=[True, False])

# Get top 5 items per cluster
top_items_per_cluster = cluster_item_counts.groupby('Cluster').head(5)

# Print top items per cluster
print("\nTop 5 purchased items per cluster:")
for cluster in top_items_per_cluster['Cluster'].unique():
    print(f"\nCluster {cluster}:")
    print(top_items_per_cluster[top_items_per_cluster['Cluster'] == cluster][['StockCode', 'Quantity']].to_markdown(index=False, numalign="left", stralign="left"))

# --- Cluster Size Visualization ---
cluster_sizes = filtered_df['Cluster'].value_counts()

# Create pie chart of cluster sizes
pie_chart_data = pd.DataFrame({'Cluster': cluster_sizes.index, 'Size': cluster_sizes.values})
base = alt.Chart(pie_chart_data).encode(
    theta=alt.Theta("Size:Q", stack=True),
    color=alt.Color("Cluster:N", legend=None),
    tooltip=['Cluster:N', 'Size:Q']
)
pie = base.mark_arc(outerRadius=120, innerRadius=0)
text = base.mark_text(radius=140, fill='white').encode(text='Size:Q')
chart = pie + text
chart.save('cluster_distribution_pie_chart.json')


# --- Recommendation System ---
def get_recommendations(customer_id, num_recommendations=5):
    cluster = filtered_df[filtered_df['Customer ID'] == customer_id]['Cluster'].iloc[0]
    customer_purchases = filtered_df[filtered_df['Customer ID'] == customer_id]['StockCode']

    # Get items frequently bought by similar customers
    cluster_purchases = filtered_df[filtered_df['Cluster'] == cluster]['StockCode']
    item_popularity = cluster_purchases.value_counts()

    # Filter out already purchased items and recommend the most popular ones
    recommendations = item_popularity[~item_popularity.index.isin(customer_purchases)].head(num_recommendations)
    return recommendations


# Save the model 
pickle.dump(kmeans, open('kmeans_model.pkl', 'wb'))
pickle.dump(customer_item_matrix, open('customer_item_matrix.pkl', 'wb'))
